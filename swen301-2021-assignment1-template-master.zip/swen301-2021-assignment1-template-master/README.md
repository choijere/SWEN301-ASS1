## SWEN301 Assignment 1 Template

Please refer to the assignment brief for details. 

